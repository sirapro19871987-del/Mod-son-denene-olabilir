package com.example.mysteriouschild.registry;

import com.example.mysteriouschild.MysteriousChildMod;
import com.example.mysteriouschild.item.MysteriousSwordItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, MysteriousChildMod.MOD_ID);

    public static final RegistryObject<Item> MYSTERIOUS_SWORD =
            ITEMS.register("mysterious_child_sword", MysteriousSwordItem::new);

    /** Sadece yaratıcı modda / test için yerleştirilebilen "taşa saplı kılıç" bloğu. */
    public static final RegistryObject<Item> SWORD_IN_STONE_ITEM =
            ITEMS.register("sword_in_stone",
                    () -> new BlockItem(ModBlocks.SWORD_IN_STONE.get(),
                            new Item.Properties().rarity(Rarity.EPIC)));

    private ModItems() {
    }
}
