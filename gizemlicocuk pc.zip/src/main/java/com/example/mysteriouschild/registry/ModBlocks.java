package com.example.mysteriouschild.registry;

import com.example.mysteriouschild.MysteriousChildMod;
import com.example.mysteriouschild.block.SwordInStoneBlock;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlocks {

    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, MysteriousChildMod.MOD_ID);

    public static final RegistryObject<Block> SWORD_IN_STONE =
            BLOCKS.register("sword_in_stone", SwordInStoneBlock::new);

    private ModBlocks() {
    }
}
