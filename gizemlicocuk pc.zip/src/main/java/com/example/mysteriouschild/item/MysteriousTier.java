package com.example.mysteriouschild.item;

import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;

/**
 * Gizemli Çocuk'un Kılıcı için özel seviye.
 * uses = 0 olduğu için eşya hasar görmez (kırılmaz).
 * attackDamageBonus çok yüksek olduğu için tek vuruşta öldürür.
 */
public class MysteriousTier implements Tier {

    public static final MysteriousTier INSTANCE = new MysteriousTier();

    private MysteriousTier() {
    }

    @Override
    public int getUses() {
        return 0;
    }

    @Override
    public float getSpeed() {
        return 12.0F;
    }

    @Override
    public float getAttackDamageBonus() {
        return 996.0F; // 1 (taban) + 996 + 3 (kılıç) = 1000 hasar
    }

    @Override
    public int getLevel() {
        return 4;
    }

    @Override
    public int getEnchantmentValue() {
        return 30;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return Ingredient.EMPTY;
    }
}
