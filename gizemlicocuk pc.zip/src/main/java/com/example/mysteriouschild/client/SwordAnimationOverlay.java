package com.example.mysteriouschild.client;

import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;

/**
 * Kılıç alındığında ekranda oynayan animasyon:
 * beyaz flaş -> kararma -> altın çizgiler + büyük başlık (küçülerek gelir) -> alt yazı -> solma.
 */
public final class SwordAnimationOverlay {

    private static final long DURATION_MS = 7000L;
    private static long startTime = -1L;

    private SwordAnimationOverlay() {
    }

    public static void start() {
        startTime = System.currentTimeMillis();
    }

    public static final IGuiOverlay OVERLAY = (gui, graphics, partialTick, width, height) -> {
        if (startTime < 0L) {
            return;
        }
        long elapsed = System.currentTimeMillis() - startTime;
        if (elapsed > DURATION_MS) {
            startTime = -1L;
            return;
        }

        // Genel zarf: 0.8 sn'de belirir, son 1.5 sn'de solar
        float envelope = Math.min(smooth(elapsed, 0, 800), 1.0F - smooth(elapsed, DURATION_MS - 1500, DURATION_MS));

        // 1) Karartma
        graphics.fill(0, 0, width, height, argb(0.55F * envelope, 0x000000));

        // 2) Beyaz flaş (ilk 0.9 sn)
        float flash = 1.0F - smooth(elapsed, 0, 900);
        if (flash > 0.0F) {
            graphics.fill(0, 0, width, height, argb(0.85F * flash, 0xFFFFFF));
        }

        // 3) Düşen altın parçacıklar
        for (int i = 0; i < 48; i++) {
            float seed = (i * 0.6180339F) % 1.0F;
            float speed = 0.00008F + (i % 5) * 0.00003F;
            float progress = (seed + elapsed * speed) % 1.0F;
            int px = (int) (seed * width);
            int py = (int) (progress * height);
            int size = 1 + (i % 3);
            graphics.fill(px, py, px + size, py + size, argb(0.8F * envelope, 0xFFD966));
        }

        // 4) Altın çizgiler (ortadan açılır)
        float lineGrow = smooth(elapsed, 600, 1800);
        int halfLine = (int) (width * 0.35F * lineGrow);
        int cx = width / 2;
        int cy = height / 2;
        graphics.fill(cx - halfLine, cy - 38, cx + halfLine, cy - 37, argb(envelope, 0xFFAA00));
        graphics.fill(cx - halfLine, cy + 38, cx + halfLine, cy + 39, argb(envelope, 0xFFAA00));

        Font font = Minecraft.getInstance().font;

        // 5) Başlık: büyükten küçüğe doğru gelir
        float titleIn = smooth(elapsed, 800, 1800);
        float titleScale = 4.0F - 1.5F * titleIn;
        float titleAlpha = Math.min(titleIn, envelope);
        if (argbAlpha(titleAlpha) >= 5) {
            Component title = Component.translatable("mysteriouschild.animation.title")
                    .withStyle(ChatFormatting.BOLD);
            graphics.pose().pushPose();
            graphics.pose().translate(cx, cy - 14, 0);
            graphics.pose().scale(titleScale, titleScale, 1.0F);
            graphics.drawCenteredString(font, title, 0, -font.lineHeight / 2, argb(titleAlpha, 0xFFAA00));
            graphics.pose().popPose();
        }

        // 6) Alt yazı
        float subIn = smooth(elapsed, 1800, 2800);
        float subAlpha = Math.min(subIn, envelope);
        if (argbAlpha(subAlpha) >= 5) {
            Component subtitle = Component.translatable("mysteriouschild.animation.subtitle")
                    .withStyle(ChatFormatting.ITALIC);
            graphics.pose().pushPose();
            graphics.pose().translate(cx, cy + 20, 0);
            graphics.pose().scale(1.5F, 1.5F, 1.0F);
            graphics.drawCenteredString(font, subtitle, 0, 0, argb(subAlpha, 0xFFFFFF));
            graphics.pose().popPose();
        }
    };

    /** t, [from, to] aralığında 0..1 arası yumuşak geçiş verir. */
    private static float smooth(long t, long from, long to) {
        float x = Mth.clamp((t - from) / (float) (to - from), 0.0F, 1.0F);
        return x * x * (3.0F - 2.0F * x);
    }

    private static int argbAlpha(float alpha) {
        return (int) (Mth.clamp(alpha, 0.0F, 1.0F) * 255.0F);
    }

    private static int argb(float alpha, int rgb) {
        return (argbAlpha(alpha) << 24) | (rgb & 0xFFFFFF);
    }
}
