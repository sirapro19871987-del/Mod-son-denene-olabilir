package com.example.mysteriouschild.network;

import com.example.mysteriouschild.MysteriousChildMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public final class ModNetwork {

    private static final String PROTOCOL_VERSION = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(MysteriousChildMod.MOD_ID, "main"),
            () -> PROTOCOL_VERSION,
            PROTOCOL_VERSION::equals,
            PROTOCOL_VERSION::equals);

    private ModNetwork() {
    }

    public static void register() {
        CHANNEL.messageBuilder(SwordClaimedPacket.class, 0, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(SwordClaimedPacket::encode)
                .decoder(SwordClaimedPacket::decode)
                .consumerMainThread(SwordClaimedPacket::handle)
                .add();
    }
}
