package com.example.mysteriouschild.network;

import com.example.mysteriouschild.client.SwordAnimationOverlay;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Sunucudan istemciye: "kılıç alındı, animasyonu başlat". */
public class SwordClaimedPacket {

    public SwordClaimedPacket() {
    }

    public static void encode(SwordClaimedPacket packet, FriendlyByteBuf buf) {
        // veri yok
    }

    public static SwordClaimedPacket decode(FriendlyByteBuf buf) {
        return new SwordClaimedPacket();
    }

    public static void handle(SwordClaimedPacket packet, Supplier<NetworkEvent.Context> ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> SwordAnimationOverlay::start);
    }
}
