package com.example.mysteriouschild.block;

import com.example.mysteriouschild.network.ModNetwork;
import com.example.mysteriouschild.network.SwordClaimedPacket;
import com.example.mysteriouschild.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;

/**
 * Taşa saplanmış kılıç. Kırılamaz; sağ tıklayınca kılıç oyuncuya verilir,
 * blok sade taşa dönüşür ve ekranda animasyon oynar.
 */
public class SwordInStoneBlock extends Block {

    public SwordInStoneBlock() {
        super(BlockBehaviour.Properties.copy(Blocks.STONE)
                .strength(-1.0F, 3600000.0F)
                .noLootTable()
                .lightLevel(state -> 8));
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide || !(level instanceof ServerLevel serverLevel)) {
            return InteractionResult.SUCCESS;
        }

        // Kılıcı ver (envanter doluysa yere düşür)
        ItemStack sword = new ItemStack(ModItems.MYSTERIOUS_SWORD.get());
        if (!player.getInventory().add(sword)) {
            player.drop(sword, false);
        }

        // Kılıç gitti: blok sade taşa dönüşür
        level.setBlock(pos, Blocks.STONE.defaultBlockState(), Block.UPDATE_ALL);

        // Efektler: yıldırım (zararsız), parçacık, ses
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(serverLevel);
        if (bolt != null) {
            bolt.moveTo(Vec3.atBottomCenterOf(pos.above()));
            bolt.setVisualOnly(true);
            serverLevel.addFreshEntity(bolt);
        }
        serverLevel.sendParticles(ParticleTypes.END_ROD,
                pos.getX() + 0.5D, pos.getY() + 1.2D, pos.getZ() + 0.5D,
                80, 0.4D, 0.8D, 0.4D, 0.08D);
        serverLevel.playSound(null, pos, SoundEvents.UI_TOAST_CHALLENGE_COMPLETE,
                SoundSource.PLAYERS, 1.0F, 0.8F);

        // Ekran animasyonunu başlat (sadece kılıcı alan oyuncuya)
        if (player instanceof ServerPlayer serverPlayer) {
            ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> serverPlayer),
                    new SwordClaimedPacket());
        }

        return InteractionResult.CONSUME;
    }
}
