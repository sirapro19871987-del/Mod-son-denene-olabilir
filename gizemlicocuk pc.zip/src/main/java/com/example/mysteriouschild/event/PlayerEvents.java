package com.example.mysteriouschild.event;

import com.example.mysteriouschild.MysteriousChildMod;
import com.example.mysteriouschild.world.SecretRoomBuilder;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = MysteriousChildMod.MOD_ID)
public class PlayerEvents {

    /** Forge'un ölümde de koruduğu kalıcı oyuncu verisi anahtarı. */
    public static final String PERSISTED_TAG = "PlayerPersisted";
    public static final String ROOM_BUILT = "mysteriouschild_room_built";
    public static final String ROOM_POS = "mysteriouschild_room_pos";

    @SubscribeEvent
    public static void onPlayerLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        if (!(player.level() instanceof ServerLevel level)) {
            return;
        }

        CompoundTag data = player.getPersistentData();
        CompoundTag persisted = data.getCompound(PERSISTED_TAG);

        if (persisted.getBoolean(ROOM_BUILT)) {
            return; // oda zaten oluşturuldu
        }

        // Oyuncunun ilk giriş (doğuş) noktasının 10 blok altına gizli oda
        BlockPos swordPos = SecretRoomBuilder.build(level, player.blockPosition());

        persisted.putBoolean(ROOM_BUILT, true);
        persisted.putLong(ROOM_POS, swordPos.asLong());
        data.put(PERSISTED_TAG, persisted);
    }
}
