package com.example.mysteriouschild.world;

import com.example.mysteriouschild.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LanternBlock;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Oyuncunun doğduğu noktanın 10 blok altında, 10x10 iç alanlı kapalı (gizli) oda oluşturur.
 * Odanın girişi yoktur; oyuncunun kazarak bulması gerekir.
 */
public final class SecretRoomBuilder {

    public static final int DEPTH = 10;
    public static final int INTERIOR_SIZE = 10;
    public static final int INTERIOR_HEIGHT = 4;

    private SecretRoomBuilder() {
    }

    /**
     * @return kılıç bloğunun konumu
     */
    public static BlockPos build(ServerLevel level, BlockPos spawn) {
        RandomSource random = level.getRandom();

        int floorY = Math.max(spawn.getY() - DEPTH, level.getMinBuildHeight() + 2);
        int cx = spawn.getX();
        int cz = spawn.getZ();

        // İç alan: 10x10
        int ix0 = cx - 5;
        int ix1 = cx + 4;
        int iz0 = cz - 5;
        int iz1 = cz + 4;

        // Dış kabuk (duvarlar dahil): iç alan + 1 blok her yöne
        for (int x = ix0 - 1; x <= ix1 + 1; x++) {
            for (int z = iz0 - 1; z <= iz1 + 1; z++) {
                for (int y = floorY; y <= floorY + INTERIOR_HEIGHT + 1; y++) {
                    boolean wall = x == ix0 - 1 || x == ix1 + 1 || z == iz0 - 1 || z == iz1 + 1;
                    boolean floor = y == floorY;
                    boolean ceiling = y == floorY + INTERIOR_HEIGHT + 1;

                    BlockState state;
                    if (floor) {
                        state = Blocks.POLISHED_DEEPSLATE.defaultBlockState();
                    } else if (wall || ceiling) {
                        state = randomBrick(random);
                    } else {
                        state = Blocks.AIR.defaultBlockState();
                    }
                    level.setBlock(new BlockPos(x, y, z), state, Block.UPDATE_CLIENTS);
                }
            }
        }

        // Köşelere asılı ruh fenerleri (ışık)
        BlockState lantern = Blocks.SOUL_LANTERN.defaultBlockState().setValue(LanternBlock.HANGING, true);
        int lanternY = floorY + INTERIOR_HEIGHT;
        level.setBlock(new BlockPos(ix0, lanternY, iz0), lantern, Block.UPDATE_CLIENTS);
        level.setBlock(new BlockPos(ix1, lanternY, iz0), lantern, Block.UPDATE_CLIENTS);
        level.setBlock(new BlockPos(ix0, lanternY, iz1), lantern, Block.UPDATE_CLIENTS);
        level.setBlock(new BlockPos(ix1, lanternY, iz1), lantern, Block.UPDATE_CLIENTS);

        // Ortadaki platform + taşa saplı kılıç
        BlockPos swordPos = new BlockPos(cx, floorY + 1, cz);
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (dx != 0 || dz != 0) {
                    level.setBlock(swordPos.offset(dx, -1, dz),
                            Blocks.CHISELED_STONE_BRICKS.defaultBlockState(), Block.UPDATE_CLIENTS);
                }
            }
        }
        level.setBlock(swordPos, ModBlocks.SWORD_IN_STONE.get().defaultBlockState(), Block.UPDATE_ALL);

        return swordPos;
    }

    private static BlockState randomBrick(RandomSource random) {
        float r = random.nextFloat();
        if (r < 0.70F) {
            return Blocks.STONE_BRICKS.defaultBlockState();
        } else if (r < 0.85F) {
            return Blocks.MOSSY_STONE_BRICKS.defaultBlockState();
        }
        return Blocks.CRACKED_STONE_BRICKS.defaultBlockState();
    }
}
