package com.example.mysteriouschild.command;

import com.example.mysteriouschild.MysteriousChildMod;
import com.example.mysteriouschild.event.PlayerEvents;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Test kolaylığı: /gizemlioda (op seviye 2) odanın koordinatını gösterir.
 */
@Mod.EventBusSubscriber(modid = MysteriousChildMod.MOD_ID)
public class RoomCommand {

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(
                Commands.literal("gizemlioda")
                        .requires(source -> source.hasPermission(2))
                        .executes(context -> {
                            ServerPlayer player = context.getSource().getPlayerOrException();
                            CompoundTag persisted = player.getPersistentData()
                                    .getCompound(PlayerEvents.PERSISTED_TAG);

                            if (!persisted.contains(PlayerEvents.ROOM_POS)) {
                                context.getSource().sendFailure(
                                        Component.literal("Bu oyuncu için gizli oda bulunamadı."));
                                return 0;
                            }

                            BlockPos pos = BlockPos.of(persisted.getLong(PlayerEvents.ROOM_POS));
                            context.getSource().sendSuccess(() -> Component.literal(
                                    "Gizemli oda: " + pos.getX() + " " + pos.getY() + " " + pos.getZ()), false);
                            return 1;
                        }));
    }
}
