package com.example.mysteriouschild;

import com.example.mysteriouschild.network.ModNetwork;
import com.example.mysteriouschild.registry.ModBlocks;
import com.example.mysteriouschild.registry.ModItems;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(MysteriousChildMod.MOD_ID)
public class MysteriousChildMod {

    public static final String MOD_ID = "mysteriouschild";

    public MysteriousChildMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();

        ModBlocks.BLOCKS.register(modBus);
        ModItems.ITEMS.register(modBus);

        modBus.addListener(this::commonSetup);
        modBus.addListener(this::addCreativeTabContents);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        event.enqueueWork(ModNetwork::register);
    }

    private void addCreativeTabContents(final BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.COMBAT) {
            event.accept(ModItems.MYSTERIOUS_SWORD);
        }
        if (event.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
            event.accept(ModItems.SWORD_IN_STONE_ITEM);
        }
    }
}
